#!/usr/bin/env python3
"""Compose a short in-film preview of the live2d_v2 actions (讲解摊手 removed).

Hard-edge + warm beige underlay, neck-plate punch, fringe cleanup and
ink-blob drop at composite time only. Does not write or touch source
frames or the official live2d pack.
"""
from __future__ import annotations

import sys
import subprocess
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

# tools/ is this file's directory
sys.path.insert(0, str(Path(__file__).resolve().parent))
from clean_v2_fringe import harden_char  # noqa: E402

V2 = Path("/workspace/bili-gamma/characters/国风Grok娘/live2d_v2/rgba")
RAW = Path("/workspace/bili-gamma/characters/国风Grok娘/live2d_v2/raw")
BG = Path("/workspace/bili-gamma/qian01-video/rebuild_v8/plates/bg/bg.png")
OUT = Path("/workspace/bili-gamma/characters/国风Grok娘/live2d_v2/国风Grok娘-live2d_v2-六动作片中预览-护皮肤.mp4")
FONT = "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc"

W, H = 1920, 1080
FPS = 24
CHAR_W, CHAR_H = 720, 1088
MARGIN = 20
CHAR_X = W - CHAR_W - MARGIN
CHAR_Y = (H - CHAR_H) // 2
INK = (48, 42, 36, 255)
INK_SOFT = (48, 42, 36, 220)

CLIPS = [
    ("idle_breath", "待机呼吸"),
    ("talk_nod", "说话点头"),
    ("curtsey", "提裙礼"),
    ("wave_hello", "挥手致意"),
    ("bow", "浅鞠躬"),
    ("think", "托腮思考"),
]


def _paste_layer(frame: Image.Image, src: Image.Image, x: int, y: int):
    cw, chh = src.size
    fw, fh = frame.size
    sx0, sy0 = max(0, -x), max(0, -y)
    sx1, sy1 = cw - max(0, x + cw - fw), chh - max(0, y + chh - fh)
    if sx1 <= sx0 or sy1 <= sy0:
        return
    if (sx0, sy0, sx1, sy1) != (0, 0, cw, chh):
        src = src.crop((sx0, sy0, sx1, sy1))
    frame.alpha_composite(src, (x + sx0, y + sy0))


def paste_char(frame, ch, under, xy):
    x, y = int(xy[0]), int(xy[1])
    _paste_layer(frame, under, x, y)
    _paste_layer(frame, ch, x, y)


def _build_jobs():
    jobs = []
    for _ in range(FPS):
        jobs.append(("title", None, None, None))
    for key, label in CLIPS:
        files = sorted((V2 / key).glob("*.png"))
        if not files:
            raise SystemExit(f"missing frames: {key}")
        for p in files:
            jobs.append(("clip", key, label, str(p)))
    return jobs


def _render_one(payload):
    i, job, bg_mode = payload
    bg = Image.open(BG).convert("RGBA")
    if bg.size != (W, H):
        bg = bg.resize((W, H), Image.Resampling.LANCZOS)
    font_title = ImageFont.truetype(FONT, 48, index=0)
    font_label = ImageFont.truetype(FONT, 36, index=0)
    font_sub = ImageFont.truetype(FONT, 26, index=0)
    frame = bg.copy()
    draw = ImageDraw.Draw(frame)
    if job[0] == "title":
        title = "国风Grok娘  live2d_v2  六动作片中预览"
        sub = "合成时硬边 + 暖色衬底 · 去领口纸底 / 去黑渣 · 官方包未改"
        tb = draw.textbbox((0, 0), title, font=font_title)
        tw, th = tb[2] - tb[0], tb[3] - tb[1]
        x, y = (W - tw) // 2, H // 2 - 40
        pad = 18
        draw.rounded_rectangle(
            (x - pad, y - pad, x + tw + pad, y + th + pad + 46),
            radius=14,
            fill=(255, 248, 230, 200),
        )
        draw.text((x, y), title, font=font_title, fill=INK)
        sb = draw.textbbox((0, 0), sub, font=font_sub)
        sw = sb[2] - sb[0]
        draw.text(((W - sw) // 2, y + th + 12), sub, font=font_sub, fill=INK_SOFT)
    else:
        _, key, label, path = job
        im = Image.open(path).convert("RGBA")
        raw_path = RAW / f"{key}_frames" / Path(path).name
        raw = np.array(Image.open(raw_path).convert("RGB")) if raw_path.exists() else None
        ch, under = harden_char(im, True, raw)
        paste_char(frame, ch, under, (CHAR_X, CHAR_Y))
        text = label
        tb = draw.textbbox((0, 0), text, font=font_label)
        tw, th = tb[2] - tb[0], tb[3] - tb[1]
        lx, ly = 72, 64
        pad = 12
        draw.rounded_rectangle(
            (lx - pad, ly - pad, lx + tw + pad, ly + th + pad),
            radius=10,
            fill=(255, 248, 230, 210),
        )
        draw.text((lx, ly), text, font=font_label, fill=INK)
    return i, frame.convert("RGB").tobytes()


def main():
    jobs = _build_jobs()
    n = len(jobs)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        "ffmpeg", "-y",
        "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS),
        "-i", "-",
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18",
        "-movflags", "+faststart",
        str(OUT),
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert proc.stdin is not None

    # Process in small ordered windows so unfinished early frames cannot
    # leave hundreds of later RGB frames sitting in memory.
    CHUNK = 36
    written = 0
    with ProcessPoolExecutor(max_workers=6) as ex:
        for start in range(0, n, CHUNK):
            batch = [(i, jobs[i], None) for i in range(start, min(start + CHUNK, n))]
            results = {i: data for i, data in ex.map(_render_one, batch, chunksize=1)}
            for i in range(start, min(start + CHUNK, n)):
                proc.stdin.write(results[i])
                written += 1
            print(f"  preview {written}/{n}", flush=True)

    proc.stdin.close()
    try:
        stdout, stderr = proc.communicate()
    except ValueError:
        stderr = proc.stderr.read() if proc.stderr else b""
        proc.wait()
        stdout = b""
    if proc.returncode not in (0, None) and proc.returncode != 0:
        sys.stderr.write((stderr or b"").decode("utf-8", "replace"))
        raise SystemExit(f"ffmpeg failed rc={proc.returncode}")
    if proc.returncode is None:
        proc.wait()
    if proc.returncode != 0:
        sys.stderr.write((stderr or b"").decode("utf-8", "replace"))
        raise SystemExit(f"ffmpeg failed rc={proc.returncode}")
    print(f"WROTE {OUT}", flush=True)
    dur = subprocess.check_output(
        ["ffprobe", "-v", "quiet", "-show_entries", "format=duration", "-of", "csv=p=0", str(OUT)],
        text=True,
    ).strip()
    print(f"duration={dur}s frames={n} fps={FPS}", flush=True)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        OUT = Path(sys.argv[1]).resolve()
    main()
