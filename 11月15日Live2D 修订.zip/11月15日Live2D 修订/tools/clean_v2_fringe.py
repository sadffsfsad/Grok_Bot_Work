#!/usr/bin/env python3
"""Composite-time edge cleanup for live2d_v2.

Removes the pale-paper rim (from i2v light plate), a thin rembg dark
fringe on the silhouette, and solid near-black matte smears left by
i2v light effects. Does not write source PNG frames.
"""
from __future__ import annotations

import cv2
import numpy as np
from PIL import Image

# New default (2026-11-15): slightly toward the in-film landscape
# footprint median (~224, 215, 194), still misty beige/cream, not green.
UNDERLAY_RGB = (228, 217, 196)
UNDERLAY_ALPHA = 0.90
UNDERLAY_CLOSE_K = 31   # ellipse; thicker than gothic 7
UNDERLAY_DILATE_K = 11  # ellipse; thicker than gothic 3, modest halo
# Previous news/gothic underlay (kept for 改前对照)
UNDERLAY_RGB_GOTHIC = (232, 220, 198)
UNDERLAY_ALPHA_GOTHIC = 0.85
# GenerateVideo / i2v paper plate (corner mean of i2v-source.png)
PAPER_RGB = np.array([247.0, 243.0, 243.0], dtype=np.float32)


def _inward_color(rgb: np.ndarray, interior: np.ndarray, steps: int = 4) -> np.ndarray:
    """Propagate interior RGB outward so edge pixels can borrow real garment/hair color."""
    out = rgb.astype(np.float32).copy()
    wgt = interior.astype(np.float32)
    k = np.ones((3, 3), np.float32)
    for _ in range(steps):
        sum_c = cv2.filter2D(out * wgt[:, :, None], -1, k, borderType=cv2.BORDER_REPLICATE)
        sum_w = cv2.filter2D(wgt, -1, k, borderType=cv2.BORDER_REPLICATE)
        fill = sum_w > 1e-6
        new = out.copy()
        for c in range(3):
            new[:, :, c] = np.where(fill, sum_c[:, :, c] / np.maximum(sum_w, 1e-6), out[:, :, c])
        out = np.where(interior[:, :, None] > 0, rgb, new)
        wgt = np.maximum(wgt, fill.astype(np.float32))
    return out


def clean_edge_fringe(arr: np.ndarray, protect: np.ndarray | None = None) -> np.ndarray:
    """Cut or recolor a 1–2px contaminated ring. Leaves interior (skirt, gold, hair) alone."""
    arr = arr.copy()
    a = arr[:, :, 3].astype(np.uint8)
    rgb = arr[:, :, :3].astype(np.float32)
    fg = (a >= 20).astype(np.uint8)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    inner = cv2.erode(fg, k, iterations=1)
    inner2 = cv2.erode(fg, k, iterations=2)
    edge = (fg == 1) & (inner == 0)
    ring = (fg == 1) & (inner2 == 0)

    luma = 0.299 * rgb[:, :, 0] + 0.587 * rgb[:, :, 1] + 0.114 * rgb[:, :, 2]
    chroma = rgb.max(2) - rgb.min(2)
    dpaper = np.linalg.norm(rgb - PAPER_RGB, axis=2)
    teal = (rgb[:, :, 1] > rgb[:, :, 0] + 8) & (rgb[:, :, 1] > 55)
    # warm blond / gold: clearly yellow, not the near-neutral paper rim
    warm_gold = ((rgb[:, :, 0] - rgb[:, :, 2]) > 40) & (chroma > 28)

    inward = _inward_color(rgb, inner2 > 0, steps=4)
    d_in = np.linalg.norm(rgb - inward, axis=2)
    in_luma = 0.299 * inward[:, :, 0] + 0.587 * inward[:, :, 1] + 0.114 * inward[:, :, 2]

    skin = protect if protect is not None else skin_mask(arr)
    # 1) drop obvious paper-white 1px rim (not gold, not already-dark teal, not skin)
    white = edge & (~warm_gold) & (~skin) & (
        (dpaper < 36)
        | ((luma > 228) & (chroma < 28))
        | ((rgb.min(2) > 205) & (chroma < 35) & (dpaper < 55))
    )
    # if inward color is also very pale (white skirt edge), prefer a 1px trim
    # rather than keeping the brighter paper mix
    a[white] = 0

    # 2) drop neutral dark rembg fringe; keep teal collar / hair bows
    black = edge & (~teal) & (~skin) & (luma < 96) & (chroma < 48)
    a[black] = 0

    # 3) remaining 2px ring: if closer to paper than to inward color, recolor
    leftover = (a >= 20) & ring & (~warm_gold) & (~skin)
    recolor = leftover & (
        ((dpaper + 8) < d_in) & (luma > 200)
        | ((luma > in_luma + 18) & (luma > 215) & (chroma < 32))
    )
    rgb[recolor] = inward[recolor]

    # 4) leftover mild dark ring: pull toward inward (don't invent teal)
    dark_fix = leftover & (~teal) & (luma < 95) & (in_luma > luma + 15)
    rgb[dark_fix] = inward[dark_fix]

    arr[:, :, :3] = np.clip(np.round(rgb), 0, 255).astype(np.uint8)
    arr[:, :, 3] = a
    arr[a == 0, :3] = 0
    return arr


def rebinarize(arr: np.ndarray, protect: np.ndarray | None = None) -> np.ndarray:
    """Hard alpha, close tiny interior holes, but do not put a dark rim back.

    The news pipeline filled restored pixels with (22, 14, 20), which vanishes
    on an emerald plate and shows as a 1px black edge on the beige 国风 plate.
    """
    solid0 = (arr[:, :, 3] >= 20).astype(np.uint8) * 255
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    solid = cv2.morphologyEx(solid0, cv2.MORPH_CLOSE, k, iterations=1)
    added = (solid > 0) & (solid0 == 0)
    # drop close-restored pixels that touch background — those are fringe, not holes
    neigh_bg = cv2.dilate((solid == 0).astype(np.uint8), np.ones((3, 3), np.uint8), 1) > 0
    solid[added & neigh_bg] = 0
    if protect is not None:
        solid[protect] = 255
    arr = arr.copy()
    arr[:, :, 3] = solid
    arr[solid == 0, :3] = 0
    filled = added & (solid > 0)
    if filled.any():
        inward = _inward_color(arr[:, :, :3].astype(np.float32), solid0 > 0, steps=4)
        arr[filled, :3] = np.clip(np.round(inward[filled]), 0, 255).astype(np.uint8)
    return arr


def _paint_underlay(alpha: np.ndarray, rgb, close_k: int, dilate_k: int, opacity: float) -> Image.Image:
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close_k, close_k))
    plate = cv2.morphologyEx(alpha, cv2.MORPH_CLOSE, k, iterations=1)
    plate = cv2.dilate(plate, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (dilate_k, dilate_k)), 1)
    under = np.zeros((alpha.shape[0], alpha.shape[1], 4), dtype=np.uint8)
    under[:, :, 0] = rgb[0]
    under[:, :, 1] = rgb[1]
    under[:, :, 2] = rgb[2]
    under[:, :, 3] = (plate.astype(np.float32) * opacity).astype(np.uint8)
    return Image.fromarray(under, "RGBA")


def make_underlay_gothic(alpha: np.ndarray) -> Image.Image:
    """Previous (news/gothic) underlay, kept unchanged for 改前对照.

    7×7 ellipse MORPH_CLOSE + 3×3 ellipse dilate, RGB (232, 220, 198), alpha×0.85.
    """
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    plate = cv2.morphologyEx(alpha, cv2.MORPH_CLOSE, k, iterations=1)
    plate = cv2.dilate(plate, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)), 1)
    under = np.zeros((alpha.shape[0], alpha.shape[1], 4), dtype=np.uint8)
    under[:, :, 0] = UNDERLAY_RGB_GOTHIC[0]
    under[:, :, 1] = UNDERLAY_RGB_GOTHIC[1]
    under[:, :, 2] = UNDERLAY_RGB_GOTHIC[2]
    under[:, :, 3] = (plate.astype(np.float32) * UNDERLAY_ALPHA_GOTHIC).astype(np.uint8)
    return Image.fromarray(under, "RGBA")


def make_underlay(alpha: np.ndarray) -> Image.Image:
    """Thicker 国风 underlay (2026-11-15): fill hair/face/body holes and chin–collar notches.

    31×31 ellipse MORPH_CLOSE + 11×11 ellipse dilate, RGB (228, 217, 196), alpha×0.90.
    Sized to cover measured hair/collar gaps, not the large enclosed arm–torso bays.
    """
    return _paint_underlay(
        alpha, UNDERLAY_RGB, UNDERLAY_CLOSE_K, UNDERLAY_DILATE_K, UNDERLAY_ALPHA
    )


def get_face(arr: np.ndarray):
    """Largest head-region skin blob after erosion, so a hand or shoulder is not merged in."""
    a = arr[:, :, 3]
    rgb = arr[:, :, :3].astype(np.int16)
    r, g, b = rgb[:, :, 0], rgb[:, :, 1], rgb[:, :, 2]
    skin = (
        (a >= 20)
        & (r > 170) & (g > 120) & (b > 90)
        & ((r - g) < 55) & ((r - b) > 18) & ((r - b) < 80)
    )
    # 9x9 once: splits shoulders, keeps the chin attached even with an open mouth.
    # Two iterations over-erodes and fragments the face (then the mouth/teeth get punched).
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
    er = cv2.erode(skin.astype(np.uint8), k, iterations=1)
    n, lab, st, _ = cv2.connectedComponentsWithStats(er, 8)
    cands = []
    for i in range(1, n):
        area = int(st[i, cv2.CC_STAT_AREA])
        top = int(st[i, cv2.CC_STAT_TOP])
        left = int(st[i, cv2.CC_STAT_LEFT])
        w = int(st[i, cv2.CC_STAT_WIDTH])
        h = int(st[i, cv2.CC_STAT_HEIGHT])
        bcx = int(left + w / 2)
        # arms / lower torso out; keep lowered heads during bow / curtsey
        if area < 600 or h > 280 or top > 320:
            continue
        if not (180 <= bcx <= 560):
            continue
        if (h / max(w, 1) > 2.8) and w < 50:
            continue
        cands.append((top, area, i, left, w, h, bcx))
    if not cands:
        for i in range(1, n):
            area = int(st[i, cv2.CC_STAT_AREA])
            top = int(st[i, cv2.CC_STAT_TOP])
            if area < 150 or top > 320:
                continue
            cands.append((top, area, i, 0, 0, 0, 0))
        if not cands:
            return None
    # Prefer the highest (smallest top) compact blobs — a shoulder can be
    # larger than the face and used to win a max-area vote, which then
    # punches a hole in the arm. Merge nearby high fragments (open mouth).
    min_top = min(c[0] for c in cands)
    high = [c for c in cands if c[0] <= min_top + 48]
    seed = np.zeros(lab.shape, dtype=bool)
    for c in high:
        seed |= lab == c[2]
    face = (cv2.dilate(seed.astype(np.uint8), k, iterations=3) & skin).astype(bool)
    ys, xs = np.where(face)
    if len(ys) == 0:
        return None
    top = int(ys.min())
    # cx from the upper face so a hand on the cheek does not pull the center
    mid = min(face.shape[0], top + 90)
    uxs = np.where(face[top:mid])[1]
    cx = int(uxs.mean()) if len(uxs) else int(xs.mean())
    x0, x1 = max(0, cx - 58), min(face.shape[1], cx + 58)
    cys, _ = np.where(face[:, x0:x1])
    chin = int(cys.max()) if len(cys) else int(ys.max())
    # clip a hand / shoulder that remained attached
    chin = min(chin, top + 170)
    # bridge a short teeth-gap if the chin island sits just below
    y = chin + 1
    miss = 0
    h, w = face.shape
    while y < min(h, top + 175):
        band = skin[y, x0:x1]
        if int(band.sum()) >= 5:
            xs_row = np.where(skin[y])[0]
            xs_row = xs_row[(xs_row >= cx - 80) & (xs_row <= cx + 80)]
            # a hand on the cheek makes the mid-face wider than 110;
            # only treat a wide row as a shoulder once past a full jaw.
            if len(xs_row) and int(xs_row.max() - xs_row.min()) > 110 and y > top + 150:
                break
            face[y, x0:x1] = band
            chin = y
            miss = 0
        else:
            miss += 1
            # a finger or an open mouth can gap the mid column for ~20–30px
            if miss > 34:
                break
        y += 1
    face[chin + 4 :] = False
    return {"top": top, "chin": chin, "cx": cx, "face": face}



def skin_mask(arr: np.ndarray) -> np.ndarray:
    """Outline original skin: face, ears, hands, arms, exposed shoulders.

    Uses peach (pink-leaning) color plus face geometry. Blonde hair and
    near-neutral paper wings stay out — they would otherwise be protected
    and the under-jaw paper could not be punched.
    """
    a = arr[:, :, 3]
    rgb = arr[:, :, :3].astype(np.int16)
    r, g, b = rgb[:, :, 0], rgb[:, :, 1], rgb[:, :, 2]
    chroma = np.maximum(np.maximum(r, g), b) - np.minimum(np.minimum(r, g), b)
    peach = (
        (a >= 20)
        & (r > 160) & (g > 100) & (b > 70)
        & ((r - g) >= 12) & ((r - g) <= 55)
        & ((r - b) >= 22) & ((r - b) <= 85)
        & (chroma >= 22)
        & ((r - b) > (r - g) + 6)
    )
    h, w = a.shape
    skin = np.zeros((h, w), dtype=bool)
    fi = get_face(arr)
    if fi is not None:
        face = fi["face"]
        k5 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        skin |= cv2.morphologyEx(face.astype(np.uint8), cv2.MORPH_CLOSE, k5).astype(bool)
        dist = cv2.distanceTransform((~face).astype(np.uint8), cv2.DIST_L2, 3)
        # ears, jaw, a hand on the cheek — not the long hanging hair
        skin |= peach & (dist <= 28)
        chin, cx, top = int(fi["chin"]), int(fi["cx"]), int(fi["top"])
        # hard head plate: even if get_face chin stopped at the mouth, keep
        # peach / lip pixels down to a full jaw. Paper wings stay out (not peach).
        y1 = min(h, max(chin, top + 168) + 8)
        x0h, x1h = max(0, cx - 100), min(w, cx + 100)
        lips = (
            (a >= 20)
            & (r > 140) & (g > 55) & (b > 55)
            & ((r - g) > 18)
            & ((r - b) > 18)
            & (r > g) & (r > b)
        )
        head = np.zeros((h, w), dtype=bool)
        head[top:y1, x0h:x1h] = True
        # upper face: keep every opaque pixel (pale cheek highlights included).
        # below the jaw line, only peach/lips — paper wings can still be punched.
        yy_h, _ = np.ogrid[:h, :w]
        skin |= head & (a >= 20) & ((yy_h < chin - 8) | peach | lips)
    else:
        chin, cx, top = h // 4, w // 2, h // 8

    # exposed shoulders: relative to the waist, not a leaning face, so the
    # 抹胸 (centered on the torso) stays out of the band.
    yy, xx = np.ogrid[:h, :w]
    waist = torso_cx(arr, cx)
    sh_band = (
        (yy > chin - 5)
        & (yy < chin + 140)
        & (
            ((np.abs(xx - cx) >= 48) & (np.abs(xx - cx) < 190))
            | ((np.abs(xx - waist) >= 50) & (np.abs(xx - waist) < 200))
        )
    )
    skin |= peach & sh_band
    sh = skin & sh_band
    sh = cv2.morphologyEx(
        sh.astype(np.uint8),
        cv2.MORPH_CLOSE,
        cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (21, 21)),
    ).astype(bool)
    skin |= sh & (a >= 20) & sh_band
    # large pale highlights that are too big for close, still on the shoulder
    near_sh = cv2.dilate((peach & sh_band).astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (21, 21)))
    pale_hi = (
        (a >= 20)
        & (r > 220) & (g > 175) & (b > 155)
        & ((r - b) <= 50)
        & ((r - g) <= 40)
        & (chroma <= 50)
        & sh_band
        & (yy > chin + 22)
        & near_sh.astype(bool)
    )
    skin |= pale_hi
    # hands / visible forearms: compact peach blobs, not wide dress panels
    n, lab, st, _ = cv2.connectedComponentsWithStats(peach.astype(np.uint8), 8)
    for i in range(1, n):
        area = int(st[i, cv2.CC_STAT_AREA])
        if area < 200 or area > 5000:
            continue
        x, y, bw, bh = map(int, st[i, :4])
        cy = y + bh / 2.0
        cx_i = x + bw / 2.0
        short = max(min(bw, bh), 1)
        aspect = max(bw, bh) / short
        if aspect > 2.4 or short < 18:
            continue
        if (chin + 40) < cy < (chin + 500) and abs(cx_i - cx) < 360:
            skin[lab == i] = True

    k5 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    skin = cv2.morphologyEx(skin.astype(np.uint8), cv2.MORPH_CLOSE, k5)
    return (skin > 0) & (a >= 20)


def _find_face_top(arr: np.ndarray):
    fi = get_face(arr)
    if fi is None:
        return None
    return fi["top"], fi["cx"]




def torso_cx(arr: np.ndarray, default_cx: int) -> int:
    """Waist/skirt opaque median, more stable than the face when the head leans."""
    a = arr[:, :, 3]
    h, w = a.shape
    y0, y1 = min(h, 520), min(h, 640)
    xs = np.where(a[y0:y1] >= 20)[1]
    if xs.size < 100:
        return int(default_cx)
    lo, hi = np.percentile(xs, [20, 80])
    mid = xs[(xs >= lo) & (xs <= hi)]
    if mid.size < 50:
        return int(default_cx)
    return int(np.median(mid))


def collar_bodice(arr: np.ndarray, fi: dict) -> tuple[int, np.ndarray]:
    """抹胸 between the two teal lapels, from just above the collar-top down.

    ctop is the 5th-percentile Y of teal in the collar box (not the axe or bows).
    The opening is the gap between the nearest teal on each side of the face
    center — more stable than the largest gap in the row, which can jump to a
    sleeve or ribbon.
    """
    a = arr[:, :, 3]
    rgb = arr[:, :, :3].astype(np.int16)
    r, g, b = rgb[:, :, 0], rgb[:, :, 1], rgb[:, :, 2]
    teal = (g > r + 8) & (g > 55) & (a >= 20)
    chin, cx = int(fi["chin"]), int(fi["cx"])
    h, w = a.shape
    waist0 = torso_cx(arr, cx)
    x0 = max(0, min(cx, waist0) - 170)
    x1 = min(w, max(cx, waist0) + 170)
    y0, y1 = max(0, chin - 10), min(h, chin + 220)
    collar = np.zeros((h, w), dtype=bool)
    collar[y0:y1, x0:x1] = teal[y0:y1, x0:x1]
    if not collar.any():
        return chin + 24, np.zeros((h, w), dtype=bool)
    ctop = int(np.percentile(np.where(collar)[0], 5))
    waist = torso_cx(arr, cx)
    if abs(waist - cx) >= 40:
        # head has leaned off the torso; split at a teal opening that
        # actually contains the waist, not at the face (which sits on a sleeve)
        mids = []
        yb0, yb1 = min(h, ctop + 10), min(h, ctop + 80)
        for y in range(yb0, yb1):
            xs = np.where(collar[y])[0]
            if xs.size < 4:
                continue
            gaps = np.diff(xs)
            for i, g in enumerate(gaps):
                if g < 12 or g > 100:
                    continue
                left, right = int(xs[i]), int(xs[i + 1])
                if left < waist < right:
                    mids.append((left + right) / 2.0)
        body_cx = int(round(np.median(mids))) if mids else waist
    else:
        yb0, yb1 = min(h, ctop + 8), min(h, ctop + 70)
        xb0, xb1 = max(0, cx - 90), min(w, cx + 90)
        chest_xs = np.where(collar[yb0:yb1, xb0:xb1])[1]
        body_cx = int(np.median(chest_xs)) + xb0 if chest_xs.size else cx
    body_cx = min(max(body_cx, x0 + 20), x1 - 20)
    y_start = max(0, ctop - 6)
    inners = {}
    for y in range(y_start, y1):
        left = np.where(collar[y, x0:body_cx])[0]
        right = np.where(collar[y, body_cx:x1])[0]
        if left.size == 0 or right.size == 0:
            continue
        inner_l = x0 + int(left.max())
        inner_r = body_cx + int(right.min())
        if inner_r - inner_l < 12 or inner_r - inner_l > 100:
            continue
        inners[y] = (inner_l, inner_r)
    bodice = np.zeros((h, w), dtype=bool)
    if inners:
        ys = sorted(inners)
        for y in range(ys[0], ys[-1] + 1):
            if y in inners:
                il, ir = inners[y]
            else:
                prev = max((k for k in ys if k < y), default=None)
                nxt = min((k for k in ys if k > y), default=None)
                if prev is not None and nxt is not None:
                    t = (y - prev) / (nxt - prev)
                    il = int(round(inners[prev][0] * (1 - t) + inners[nxt][0] * t))
                    ir = int(round(inners[prev][1] * (1 - t) + inners[nxt][1] * t))
                elif prev is not None:
                    il, ir = inners[prev]
                else:
                    il, ir = inners[nxt]
            bodice[y, il + 1 : ir] = a[y, il + 1 : ir] >= 20
        # also fill a few rows above the first detection down from ctop
        # do not fill past the sash: once the opening is much wider than
        # the high collar and well below ctop, those rows are skirt/sleeves
        cap = None
        for y in ys:
            if y > ctop + 90 and (inners[y][1] - inners[y][0]) > 110:
                cap = y
                break
        if cap is not None:
            inners = {k: v for k, v in inners.items() if k < cap}
            ys = sorted(inners)
        il0, ir0 = inners[ys[0]]
        for y in range(y_start, ys[0]):
            bodice[y, il0 + 1 : ir0] = a[y, il0 + 1 : ir0] >= 20
        k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
        bodice = cv2.morphologyEx(bodice.astype(np.uint8), cv2.MORPH_CLOSE, k).astype(bool)
        # clip to the waist column (more stable than a leaning-face body_cx)
        x0c, x1c = max(0, waist - 80), min(w, waist + 95)
        y0c, y1c = max(0, ctop - 6), min(h, ctop + 170)
        clipped = np.zeros_like(bodice)
        clipped[y0c:y1c, x0c:x1c] = bodice[y0c:y1c, x0c:x1c]
        clipped = cv2.morphologyEx(
            clipped.astype(np.uint8),
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (21, 21)),
        ).astype(bool)
        # pale 抹胸 highlights sitting on the opening, below the high collar
        luma = (0.2126 * arr[:, :, 0] + 0.7152 * arr[:, :, 1] + 0.0722 * arr[:, :, 2])
        near = cv2.dilate(clipped.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (21, 21)))
        yy = np.arange(h)[:, None]
        pale = (a >= 20) & (luma > 210) & (yy > ctop + 8) & (yy < y1c)
        pale[:, :x0c] = False
        pale[:, x1c:] = False
        bodice = (clipped | (pale & near.astype(bool))) & (a >= 20)
    return ctop, bodice


def punch_neck_plate(arr: np.ndarray, raw: np.ndarray | None = None, protect: np.ndarray | None = None) -> np.ndarray:
    """Drop leftover i2v paper stuck as under-jaw wings (not the pale 抹胸 or earrings)."""
    arr = arr.copy()
    fi = get_face(arr)
    if fi is None:
        return arr
    a = arr[:, :, 3]
    rgb = arr[:, :, :3].astype(np.float32)
    luma = 0.299 * rgb[:, :, 0] + 0.587 * rgb[:, :, 1] + 0.114 * rgb[:, :, 2]
    chroma = arr[:, :, :3].max(2).astype(int) - arr[:, :, :3].min(2).astype(int)
    if raw is not None:
        raw_rgb = np.asarray(raw)[:, :, :3].astype(np.float32)
        paper = np.median(
            np.concatenate([raw_rgb[0], raw_rgb[-1], raw_rgb[:, 0], raw_rgb[:, -1]]), 0
        ).astype(np.float32)
        raw_d = np.linalg.norm(raw_rgb - paper, axis=2)
        pale = (a >= 20) & (luma > 220) & (chroma < 34) & (raw_d < 24)
    else:
        d = np.linalg.norm(rgb - PAPER_RGB, axis=2)
        pale = (a >= 20) & (luma > 220) & (chroma < 34) & (d < 24)
    # keep blonde hair and skin (face/hands/shoulders); paper wings are near-neutral
    warm_hair = ((rgb[:, :, 0] - rgb[:, :, 2]) > 36) & (chroma > 26)
    skin = protect if protect is not None else skin_mask(arr)
    pale = pale & (~warm_hair) & (~skin)

    face = fi["face"]
    chin, cx, top = fi["chin"], fi["cx"], fi["top"]
    jaw = face.copy()
    # only the chin itself, not the cheeks — a mid-face halo punches hair next to the cheek
    cut = top + int(0.72 * (chin - top))
    jaw[:cut] = False
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (17, 17))
    halo = cv2.dilate(jaw.astype(np.uint8), k, 1).astype(bool)
    yj0, yj1 = max(0, chin - 12), max(1, chin - 1)
    jxs = np.where(face[yj0:yj1].any(0))[0]
    if len(jxs):
        xl, xr = int(jxs.min()), int(jxs.max())
        y0, y1 = max(0, chin - 15), min(face.shape[0], chin + 30)
        # inward to cx-12 so the collar-gap paper (just inside the jaw) is included;
        # mid-band + chin+30 still keep the 抹胸 out
        halo[y0:y1, max(0, xl - 55) : min(face.shape[1], cx - 12)] = True
        halo[y0:y1, max(0, cx + 12) : min(face.shape[1], xr + 55)] = True
    halo = halo & (~face)
    halo[chin + 30 :] = False
    halo[: max(0, top + 50)] = False
    ctop, bodice = collar_bodice(arr, fi)
    halo &= ~bodice
    cand = pale & halo
    n, lab, st, _ = cv2.connectedComponentsWithStats(cand.astype(np.uint8), 8)
    punch = np.zeros(face.shape, dtype=bool)
    for i in range(1, n):
        area = int(st[i, cv2.CC_STAT_AREA])
        if area < 25:
            continue
        x, y, w, h = map(int, st[i, :4])
        if h >= 2.6 * max(w, 1) and w <= 28:
            continue
        if w > 48 and area > 700:
            continue
        punch[lab == i] = True
    # near-neutral paper left in the jaw–collar gap (halo can miss it
    # when a hand on the cheek shifts the jaw box)
    paper_gap = (a >= 20) & (luma > 215) & (chroma < 18) & (~warm_hair) & (~skin) & (~bodice)
    if raw is not None:
        paper_gap = paper_gap & (raw_d < 26)
    else:
        dpap = np.linalg.norm(rgb - PAPER_RGB, axis=2)
        paper_gap = paper_gap & (dpap < 26)
    gap = np.zeros(a.shape, dtype=bool)
    gap[max(0, chin - 15) : min(a.shape[0], ctop + 12), max(0, cx - 150) : min(a.shape[1], cx + 150)] = True
    gap &= ~bodice
    punch = punch | (paper_gap & gap)
    if punch.any():
        punch = cv2.morphologyEx(
            punch.astype(np.uint8),
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)),
        ).astype(bool)
        face_prot = cv2.dilate(
            face.astype(np.uint8),
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (21, 21)),
            1,
        ).astype(bool)
        punch = punch & (a >= 20) & (~face_prot) & (~skin) & (~bodice)
        dt = cv2.distanceTransform((~jaw).astype(np.uint8), cv2.DIST_L2, 3)
        punch = punch & (dt <= 60)
    # paper triangles between hanging hair and the teal collar, often
    # wider/lower than the jaw halo (curtsey, bow, standing frames)
    teal = (rgb[:, :, 1] > rgb[:, :, 0] + 8) & (rgb[:, :, 1] > 55) & (a >= 20)
    y0p, y1p = max(0, chin - 50), min(a.shape[0], min(chin + 52, ctop + 36))
    # high collar only — a wider x window would pick up sleeve teal
    x0p, x1p = max(0, cx - 110), min(a.shape[1], cx + 110)
    teal_band = np.zeros(a.shape, dtype=bool)
    teal_band[y0p:y1p, x0p:x1p] = teal[y0p:y1p, x0p:x1p]
    k21 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (21, 21))
    hair_d = cv2.dilate(warm_hair.astype(np.uint8), k21)
    teal_d = cv2.dilate(teal_band.astype(np.uint8), k21)
    pocket_pale = (a >= 20) & (luma > 215) & (chroma < 22) & (~warm_hair) & (~skin) & (~bodice)
    if raw is not None:
        pocket_pale = pocket_pale & (raw_d < 30)
    else:
        dpap = np.linalg.norm(rgb - PAPER_RGB, axis=2)
        pocket_pale = pocket_pale & (dpap < 30)
    pocket = pocket_pale & hair_d.astype(bool) & teal_d.astype(bool)
    # never punch the 抹胸 / collar opening, even if bodice missed a few rows
    open_prot = cv2.dilate(bodice.astype(np.uint8), cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11)))
    pocket &= ~open_prot.astype(bool)
    pocket[: max(0, top + 50)] = False
    pocket[y1p:] = False
    pocket[:, :x0p] = False
    pocket[:, x1p:] = False
    punch = punch | pocket
    a = a.copy()
    a[punch] = 0
    arr[:, :, 3] = a
    arr[a == 0, :3] = 0
    return arr


def drop_ink_blobs(arr: np.ndarray, protect: np.ndarray | None = None) -> np.ndarray:
    """Drop solid near-black matte smears left by i2v light effects.

    Floods from the frame edge through background and near-ink (plus a 1px
    mid-gray seal) so both open smears and closed pockets are cut. Growth
    stays on dark-gray junk that already touches the background, so gold
    ferrules, jade tips, and pale skirt highlights are left alone.
    Does not write source PNG frames.
    """
    arr = arr.copy()
    a = arr[:, :, 3].copy()
    rgb = arr[:, :, :3].astype(np.float32)
    r, g, b = rgb[:, :, 0], rgb[:, :, 1], rgb[:, :, 2]
    luma = 0.299 * r + 0.587 * g + 0.114 * b
    chroma = rgb.max(2) - rgb.min(2)
    fg = a >= 20
    bg = ~fg
    ink = fg & (luma < 22) & (chroma < 20)
    near = fg & (luma < 32) & (chroma < 24)
    h, w = a.shape

    walk = (bg | near).astype(np.uint8)
    k2 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    walk = cv2.dilate(walk, k2, iterations=1)
    walk = walk & (bg | ((chroma < 36) | (luma < 42))).astype(np.uint8)

    padded = np.ones((h + 2, w + 2), np.uint8)
    padded[1:-1, 1:-1] = walk
    img = padded.copy()
    mask = np.zeros((h + 4, w + 4), np.uint8)
    cv2.floodFill(img, mask, (0, 0), 2, 0, 0, cv2.FLOODFILL_FIXED_RANGE)
    reached = img[1:-1, 1:-1] == 2
    pockets = (bg | near) & (~reached)
    target = ink & (reached | pockets)

    fi = get_face(arr)
    if fi is not None:
        face_d = cv2.dilate(
            fi["face"].astype(np.uint8), np.ones((9, 9), np.uint8), 1
        ).astype(bool)
        target = target & (~face_d)
    if protect is not None:
        target = target & (~protect)

    n, lab, st, _ = cv2.connectedComponentsWithStats(target.astype(np.uint8), 8)
    drop = np.zeros((h, w), dtype=bool)
    for i in range(1, n):
        area = int(st[i, cv2.CC_STAT_AREA])
        y = int(st[i, cv2.CC_STAT_TOP])
        if area < 8:
            continue
        # shoe soles can be naturally very dark; keep tiny ones
        if y >= 1020 and area < 50:
            continue
        drop[lab == i] = True

    if drop.any():
        warm = ((r - b) > 36) & (chroma > 26)
        strong_teal = (g > r + 10) & (chroma > 32) & (luma > 50)
        dark_junk = fg & (luma < 55) & (chroma < 30) & (~warm) & (~strong_teal)
        exposed = cv2.dilate(
            bg.astype(np.uint8),
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)),
            1,
        ).astype(bool)
        allowed = ((dark_junk & exposed) | drop).astype(np.uint8)
        grown = drop.astype(np.uint8)
        k = np.ones((3, 3), np.uint8)
        for _ in range(20):
            nxt = cv2.dilate(grown, k, 1) & allowed
            if np.array_equal(nxt, grown):
                break
            grown = nxt
        drop = grown.astype(bool)

    if protect is not None:
        drop = drop & (~protect)
    a[drop] = 0
    arr[:, :, 3] = a
    arr[a == 0, :3] = 0
    return arr


def harden_char(im: Image.Image, clean: bool = True, raw: np.ndarray | None = None):
    src = np.array(im.convert("RGBA"))
    arr = src.copy()
    protect = skin_mask(src) if clean else None
    if clean and protect is not None:
        fi = get_face(src)
        _, bodice = collar_bodice(src, fi)
        protect = protect | bodice
    if clean:
        arr = punch_neck_plate(arr, raw, protect=protect)
        arr = clean_edge_fringe(arr, protect=protect)
    arr = rebinarize(arr, protect=protect)
    # second pass after hard threshold, in case mid-alpha paper became solid
    if clean:
        arr = punch_neck_plate(arr, raw, protect=protect)
        arr = clean_edge_fringe(arr, protect=protect)
        arr = rebinarize(arr, protect=protect)
        # fringe once more so close cannot leave a leftover dark rim
        arr = clean_edge_fringe(arr, protect=protect)
        arr = drop_ink_blobs(arr, protect=protect)
        arr = clean_edge_fringe(arr, protect=protect)
    # hard guarantee: original skin pixels are never dropped
    if protect is not None:
        lost = protect & (arr[:, :, 3] < 20)
        if lost.any():
            arr[lost] = src[lost]
    im = Image.fromarray(arr, "RGBA")
    return im, make_underlay(arr[:, :, 3])
