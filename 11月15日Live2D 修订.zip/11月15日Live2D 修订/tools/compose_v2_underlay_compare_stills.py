#!/usr/bin/env python3
"""改前/改后对照静帧：旧哥特衬底 vs 2026-11-15 加厚衬底。

只改合成。不写源 PNG，不改官方包，不含讲解摊手，不渲整段预览视频。
"""
from __future__ import annotations

import json
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, str(Path(__file__).resolve().parent))
from clean_v2_fringe import (  # noqa: E402
    harden_char,
    make_underlay,
    make_underlay_gothic,
    get_face,
)

V2 = Path("/workspace/bili-gamma/characters/国风Grok娘/live2d_v2/rgba")
RAW = Path("/workspace/bili-gamma/characters/国风Grok娘/live2d_v2/raw")
BG = Path("/workspace/bili-gamma/qian01-video/rebuild_v8/plates/bg/bg.png")
OUT_DIR = Path(
    "/workspace/bili-gamma/characters/国风Grok娘/live2d_v2/qc/2026-11-15-thicker-underlay"
)
FONT = "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc"

W, H = 1920, 1080
CHAR_W, CHAR_H = 720, 1088
MARGIN = 20
CHAR_X = W - CHAR_W - MARGIN  # 1180
CHAR_Y = (H - CHAR_H) // 2    # -4
INK = (48, 42, 36, 255)

# holes larger than this are treated as arm–torso (or similar) bays, not defects
MAX_DEFECT_AREA = 1400
MAX_DEFECT_BOX = 90


def _paste_layer(frame: Image.Image, src: Image.Image, x: int, y: int):
    cw, chh = src.size
    fw, fh = frame.size
    sx0, sy0 = max(0, -x), max(0, -y)
    sx1, sy1 = cw - max(0, x + cw - fw), chh - max(0, y + chh - fh)
    if sx1 <= sx0 or sy1 <= sy0:
        return
    if (sx0, sy0, sx1, sy1) != (0, 0, cw, chh):
        src = src.crop((sx0, sy0, sx1, sy1))
    frame.alpha_composite(src, (x + sx0, y + sy0))


def paste_char(frame, ch, under, xy):
    x, y = int(xy[0]), int(xy[1])
    _paste_layer(frame, under, x, y)
    _paste_layer(frame, ch, x, y)


def interior_holes(fg: np.ndarray):
    """Connected components of background that do not touch the image border."""
    inv = (fg == 0).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(inv, 8)
    h, w = fg.shape
    out = []
    for i in range(1, n):
        x, y, bw, bh, area = map(int, st[i])
        if x <= 0 or y <= 0 or x + bw >= w or y + bh >= h:
            # touches (or is) the border-connected exterior
            # conservative: if bbox touches border, check actual pixels
            comp = lab == i
            if comp[0].any() or comp[-1].any() or comp[:, 0].any() or comp[:, -1].any():
                continue
        cx = x + bw // 2
        cy = y + bh // 2
        eq = 2.0 * np.sqrt(area / np.pi)
        out.append({"area": area, "eq": eq, "bw": bw, "bh": bh, "cx": cx, "cy": cy})
    return out


def defect_holes(holes, y0, y1, x0=0, x1=10000):
    sel = []
    for h in holes:
        if not (y0 <= h["cy"] < y1 and x0 <= h["cx"] < x1):
            continue
        if h["area"] > MAX_DEFECT_AREA or max(h["bw"], h["bh"]) > MAX_DEFECT_BOX:
            continue
        if h["area"] < 8:
            continue
        sel.append(h)
    return sel


def load_hardened(key: str, idx: str):
    path = V2 / key / f"{idx}.png"
    im = Image.open(path).convert("RGBA")
    raw_path = RAW / f"{key}_frames" / f"{idx}.png"
    raw = np.array(Image.open(raw_path).convert("RGB")) if raw_path.exists() else None
    ch, under_new = harden_char(im, True, raw)
    arr = np.array(ch)
    under_old = make_underlay_gothic(arr[:, :, 3])
    # under_new from harden_char already uses current make_underlay
    return ch, under_old, under_new, arr


def _analyze_one(payload):
    key, idx = payload
    ch, under_old, under_new, arr = load_hardened(key, idx)
    a = arr[:, :, 3]
    ua_old = np.array(under_old)[:, :, 3]
    ua_new = np.array(under_new)[:, :, 3]
    holes = interior_holes(a)
    rem_old = interior_holes(((a > 0) | (ua_old > 0)).astype(np.uint8) * 255)
    rem_new = interior_holes(((a > 0) | (ua_new > 0)).astype(np.uint8) * 255)
    fi = get_face(arr)
    if fi is None:
        top, chin, cx = 80, 280, 360
    else:
        top, chin, cx = int(fi["top"]), int(fi["chin"]), int(fi["cx"])
    head = defect_holes(holes, max(0, top - 40), chin + 30, max(0, cx - 200), cx + 200)
    collar = defect_holes(holes, max(0, chin - 25), chin + 90, max(0, cx - 140), cx + 140)
    head_old = defect_holes(rem_old, max(0, top - 40), chin + 30, max(0, cx - 200), cx + 200)
    collar_old = defect_holes(rem_old, max(0, chin - 25), chin + 90, max(0, cx - 140), cx + 140)
    head_new = defect_holes(rem_new, max(0, top - 40), chin + 30, max(0, cx - 200), cx + 200)
    collar_new = defect_holes(rem_new, max(0, chin - 25), chin + 90, max(0, cx - 140), cx + 140)

    def score(hs):
        if not hs:
            return 0, 0, 0
        return len(hs), int(sum(h["area"] for h in hs)), int(max(h["area"] for h in hs))

    return {
        "key": key,
        "idx": idx,
        "top": top,
        "chin": chin,
        "cx": cx,
        "n_head": score(head)[0],
        "head_area": score(head)[1],
        "head_max": score(head)[2],
        "n_collar": score(collar)[0],
        "collar_area": score(collar)[1],
        "collar_max": score(collar)[2],
        "old_head_area": score(head_old)[1],
        "old_head_max": score(head_old)[2],
        "old_collar_area": score(collar_old)[1],
        "old_collar_max": score(collar_old)[2],
        "new_head_area": score(head_new)[1],
        "new_collar_area": score(collar_new)[1],
        "new_head_max": score(head_new)[2],
        "new_collar_max": score(collar_new)[2],
    }


def list_frames(key: str, step: int = 1):
    files = sorted((V2 / key).glob("*.png"))
    if step > 1:
        files = files[::step] + ([files[-1]] if files and files[-1] not in files[::step] else [])
    return [(key, p.stem) for p in files]


def scan(jobs, workers=6):
    rows = []
    with ProcessPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(_analyze_one, j): j for j in jobs}
        n = len(futs)
        done = 0
        for fut in as_completed(futs):
            rows.append(fut.result())
            done += 1
            if done % 20 == 0 or done == n:
                print(f"  scanned {done}/{n}", flush=True)
    rows.sort(key=lambda r: (r["key"], r["idx"]))
    return rows


def pick_frames(rows):
    def sub(key):
        return [r for r in rows if r["key"] == key]

    def best(cands, keyfn, n=1):
        cands = sorted(cands, key=keyfn, reverse=True)
        return cands[:n]

    picks = {}
    curt = sub("curtsey")
    if curt:
        chins = [r["chin"] for r in curt]
        med = float(np.median(chins))
        # standing: head high (small chin); lowered: head down (large chin)
        stand = [r for r in curt if r["chin"] <= med - 8] or [r for r in curt if r["chin"] <= med]
        low = [r for r in curt if r["chin"] >= med + 15] or [r for r in curt if r["chin"] >= med]
        # 站姿领口: worst leftover collar (old underlay) among standing
        picks["curtsey_stand_collar"] = best(
            stand, lambda r: (r["old_collar_area"], r["collar_area"], r["old_collar_max"])
        )[0]
        # 低头发: worst leftover head holes among lowered
        picks["curtsey_low_hair"] = best(
            low, lambda r: (r["old_head_area"], r["head_area"], r["old_head_max"])
        )[0]

    bow = sub("bow")
    if bow:
        chins = [r["chin"] for r in bow]
        med = float(np.median(chins))
        low = [r for r in bow if r["chin"] >= med + 15] or [r for r in bow if r["chin"] >= med]
        picks["bow_low_hair"] = best(
            low, lambda r: (r["old_head_area"], r["head_area"], r["old_head_max"])
        )[0]

    think = sub("think")
    if think:
        chins = [r["chin"] for r in think]
        med = float(np.median(chins))
        # 领口: worst collar leftover; prefer not the most extreme hand-on-cheek
        # if scores are close. We'll also pick 托腮 separately.
        picks["think_collar"] = best(
            think, lambda r: (r["old_collar_area"], r["collar_area"], r["old_collar_max"])
        )[0]
        # 托腮 is the mid-hold of the think clip (hand on cheek ~0037–0085),
        # not the late return-to-stand frames. Confirmed on a contact sheet.
        tuosai_pool = [r for r in think if 37 <= int(r["idx"]) <= 85]
        if not tuosai_pool:
            tuosai_pool = think
        collar_idx = picks["think_collar"]["idx"]
        ranked = best(
            tuosai_pool,
            lambda r: (r["old_head_area"] + r["old_collar_area"], r["old_head_max"]),
            8,
        )
        alt = [r for r in ranked if r["idx"] != collar_idx]
        picks["think_tuosai"] = (alt or ranked)[0]

    extras = []
    for key in ("idle_breath", "talk_nod", "wave_hello"):
        cand = sub(key)
        if not cand:
            continue
        extras.extend(best(cand, lambda r: (r["old_head_area"] + r["old_collar_area"], r["old_head_max"]), 2))
    extras = sorted(extras, key=lambda r: (r["old_head_area"] + r["old_collar_area"]), reverse=True)
    # keep 1–2 that actually have leftover defects
    kept = []
    for r in extras:
        if r["old_head_area"] + r["old_collar_area"] < 40:
            continue
        kept.append(r)
        if len(kept) >= 2:
            break
    if kept:
        picks["extra_1"] = kept[0]
    if len(kept) >= 2:
        picks["extra_2"] = kept[1]
    return picks


def _label(draw, text, xy, font, fill=INK, bg=(255, 248, 230, 220)):
    x, y = xy
    tb = draw.textbbox((0, 0), text, font=font)
    tw, th = tb[2] - tb[0], tb[3] - tb[1]
    pad = 12
    draw.rounded_rectangle(
        (x - pad, y - pad, x + tw + pad, y + th + pad),
        radius=10,
        fill=bg,
    )
    draw.text((x, y), text, font=font, fill=fill)


def compose_panel(ch, under):
    bg = Image.open(BG).convert("RGBA")
    if bg.size != (W, H):
        bg = bg.resize((W, H), Image.Resampling.LANCZOS)
    frame = bg.copy()
    paste_char(frame, ch, under, (CHAR_X, CHAR_Y))
    return frame


def render_still(key, idx, title, out_path: Path, zoom_path: Path | None = None):
    ch, under_old, under_new, arr = load_hardened(key, idx)
    left = compose_panel(ch, under_old)
    right = compose_panel(ch, under_new)
    font_tag = ImageFont.truetype(FONT, 44, index=0)
    font_sub = ImageFont.truetype(FONT, 26, index=0)
    for panel, tag in ((left, "改前"), (right, "改后")):
        draw = ImageDraw.Draw(panel)
        _label(draw, tag, (72, 56), font_tag)
        _label(draw, f"{title}  ·  {key} {idx}", (72, 130), font_sub, bg=(255, 248, 230, 200))
    canvas = Image.new("RGB", (W * 2, H))
    canvas.paste(left.convert("RGB"), (0, 0))
    canvas.paste(right.convert("RGB"), (W, 0))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    # high-quality JPEG keeps the zip small while remaining reviewable
    canvas.save(out_path, quality=95, subsampling=0, optimize=True)

    if zoom_path is not None:
        # tight crop around the character for visual QA (not shipped)
        # character visible region on panel: x=1180..1900, full height
        x0 = CHAR_X - 20
        crop_w = CHAR_W + 40
        # for head/collar, also a taller mid crop
        fi = get_face(arr)
        if fi is None:
            cy = 280
        else:
            cy = int((fi["top"] + fi["chin"]) / 2)
        # crop in panel coords
        py = max(0, CHAR_Y + cy - 260)
        # show from a bit above head to mid-torso
        box = (x0, max(0, py), x0 + crop_w, min(H, py + 620))
        z = Image.new("RGB", ((box[2] - box[0]) * 2, box[3] - box[1]))
        z.paste(left.convert("RGB").crop(box), (0, 0))
        z.paste(right.convert("RGB").crop(box), (box[2] - box[0], 0))
        zd = ImageDraw.Draw(z)
        font_s = ImageFont.truetype(FONT, 28, index=0)
        _label(zd, "改前", (16, 12), font_s)
        _label(zd, "改后", (box[2] - box[0] + 16, 12), font_s)
        zoom_path.parent.mkdir(parents=True, exist_ok=True)
        z.save(zoom_path, quality=95, subsampling=0, optimize=True)
    return out_path


STILL_SPEC = [
    ("curtsey_stand_collar", "提裙礼-站姿领口", "01-提裙礼-站姿领口-对照.jpg"),
    ("curtsey_low_hair", "提裙礼-低头发", "02-提裙礼-低头发-对照.jpg"),
    ("bow_low_hair", "鞠躬-低头发", "03-鞠躬-低头发-对照.jpg"),
    ("think_collar", "思考-领口", "04-思考-领口-对照.jpg"),
    ("think_tuosai", "思考-托腮", "05-思考-托腮-对照.jpg"),
]


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    dbg = OUT_DIR / "_dbg"
    dbg.mkdir(parents=True, exist_ok=True)

    jobs = []
    jobs += list_frames("curtsey", 1)
    jobs += list_frames("bow", 1)
    jobs += list_frames("think", 1)
    # subsample extras
    jobs += list_frames("idle_breath", 4)
    jobs += list_frames("talk_nod", 4)
    jobs += list_frames("wave_hello", 4)
    print(f"scanning {len(jobs)} frames for problem spots", flush=True)
    rows = scan(jobs)
    (dbg / "scan.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2))

    picks = pick_frames(rows)
    print("\n======= picks =======", flush=True)
    for k, r in picks.items():
        print(
            f"  {k:24s} {r['key']:12s} {r['idx']} chin={r['chin']} top={r['top']} "
            f"old_headA={r['old_head_area']} old_colA={r['old_collar_area']} "
            f"new_headA={r['new_head_area']} new_colA={r['new_collar_area']}",
            flush=True,
        )
    (dbg / "picks.json").write_text(json.dumps(picks, ensure_ascii=False, indent=2))

    # extras file names
    specs = list(STILL_SPEC)
    ACTION_ZH = {
        "idle_breath": "待机呼吸",
        "talk_nod": "说话点头",
        "wave_hello": "挥手致意",
    }
    n_extra = 0
    for ek in ("extra_1", "extra_2"):
        if ek not in picks:
            continue
        n_extra += 1
        r = picks[ek]
        zh = ACTION_ZH.get(r["key"], r["key"])
        # prefer describing the worse region
        part = "头发" if r["old_head_area"] >= r["old_collar_area"] else "领口"
        fname = f"{5+n_extra:02d}-{zh}-{part}-对照.jpg"
        specs.append((ek, f"{zh}-{part}", fname))

    written = []
    for key_id, title, fname in specs:
        if key_id not in picks:
            print(f"SKIP missing pick {key_id}", flush=True)
            continue
        r = picks[key_id]
        outp = OUT_DIR / fname
        zp = dbg / fname.replace("-对照.jpg", "-zoom.jpg")
        print(f"render {fname} <- {r['key']} {r['idx']}", flush=True)
        render_still(r["key"], r["idx"], title, outp, zp)
        written.append(str(outp))
        print(f"  WROTE {outp} + zoom {zp}", flush=True)

    manifest = {"picks": picks, "files": written}
    (OUT_DIR / "stills_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2)
    )
    print("DONE", len(written), "stills", flush=True)


if __name__ == "__main__":
    main()
