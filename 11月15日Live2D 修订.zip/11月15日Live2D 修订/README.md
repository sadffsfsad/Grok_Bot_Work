# 11月15日 Live2D 修订

国风 Grok 娘 live2d_v2 **加厚衬底**合成修订。只改合成，不改源帧，不改官方包。本次未上传 Drive / GitHub，也未重渲六动作预览视频。

## 衬底参数

| | 改前（哥特/新闻同款，`make_underlay_gothic`） | 改后（新默认 `make_underlay`） |
| --- | --- | --- |
| 闭运算 | 7×7 椭圆 MORPH_CLOSE | 31×31 椭圆 MORPH_CLOSE |
| 膨胀 | 3×3 椭圆 | 11×11 椭圆 |
| 颜色 | (232, 220, 198) | (228, 217, 196) |
| 不透明度 | 0.85 | 0.90 |

新米色略向片中山水底角色落幅的中位 (~224, 215, 194) 靠，并贴近头顶/领口一带的雾色纸调，保持米色，没有改成绿色。核加大是为了堵住头发/脸/身体内部空洞和领口浅纸缝；下巴–领口向外开口的窄槽靠膨胀盖住。手臂与身体之间的大空腔、斧头装饰镂空有意不填。发梢/裙边允许一圈淡米色光晕。

## 包内有什么

```
11月15日Live2D 修订/
  README.md                                          本说明
  tools/
    clean_v2_fringe.py                               已切换为新衬底默认
    clean_v2_fringe.py.bak-before-thick-underlay     改前备份（与 11-12 版本一致）
    compose_v2_infilm_preview.py                     六动作片中预览脚本（未改逻辑；harden_char 会走新衬底）
    compose_v2_underlay_compare_stills.py            本次对照静帧脚本
  qc/2026-11-15-thicker-underlay/
    README.md                                        对照说明（核、颜色、帧号）
    01-提裙礼-站姿领口-对照.jpg                      curtsey 0071
    02-提裙礼-低头发-对照.jpg                        curtsey 0031
    03-鞠躬-低头发-对照.jpg                          bow 0027
    04-思考-领口-对照.jpg                            think 0106
    05-思考-托腮-对照.jpg                            think 0045
    06-挥手致意-领口-对照.jpg                        wave_hello 0001
    07-说话点头-头发-对照.jpg                        talk_nod 0013
    stills_manifest.json
```

对照图是 3840×1080（左改前 / 右改后），角色贴在 `rebuild_v8` 山水底上，位置与既有预览相同。不含讲解摊手。

## 明确未包含、也未改动

- `live2d_v2/rgba/` 源 PNG（含 point_explain，源帧仍在磁盘）
- `live2d_v2/raw/` 原始视频与拆帧
- 官方包 `characters/国风Grok娘/live2d/`
- 旧的预览 mp4

## 还剩什么

近看时，下巴底下的米色衬板比山水底的纸纹更平一点；发梢和裙边有一圈淡米色光晕；个别未闭合或过大的缝可能还在。斧头上的装饰镂空保持镂空。皮肤和抹胸高光未切、未涂。

**六动作预览视频请等确认对照静帧后再重渲。**
